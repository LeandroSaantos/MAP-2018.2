package PizzariaNovaYork;

public class Pepperoni {

}

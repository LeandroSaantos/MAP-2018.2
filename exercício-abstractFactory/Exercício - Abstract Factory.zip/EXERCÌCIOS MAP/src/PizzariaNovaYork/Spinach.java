package PizzariaNovaYork;

public class Spinach extends Veggies {

}

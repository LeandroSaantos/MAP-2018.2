package PizzariaNovaYork;

import PizzariaNovaYork.PizzaStoreAF.Cheese;

public class ReggianoCheese implements Cheese {

}

package PizzariaNovaYork;

public class Eggplant extends Veggies{

}

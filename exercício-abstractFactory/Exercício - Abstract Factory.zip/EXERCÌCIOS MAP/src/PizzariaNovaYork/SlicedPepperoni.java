package PizzariaNovaYork;

import PizzariaNovaYork.PizzaStoreAF.Pepperoni;

public class SlicedPepperoni implements Pepperoni {

}

package PizzariaNovaYork;

public class BlackOlives extends Veggies{

}

package PizzariaNovaYork;

public class FreshClams extends Clams {

}

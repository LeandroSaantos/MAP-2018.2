package PizzariaNovaYork;

public class Veggies {

}
